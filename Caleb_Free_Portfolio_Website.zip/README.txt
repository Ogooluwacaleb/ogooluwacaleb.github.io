# Caleb Portfolio

This is a simple, mobile-friendly portfolio website for Ogooluwayimika Caleb.

## Before publishing
1. Open `index.html`.
2. Replace `YOUR-EMAIL@example.com` with your real email.
3. Review the sample projects and edit anything that does not accurately describe your abilities.

## Free publishing
You can publish this site with GitHub Pages using a free GitHub account. The resulting page can be used as the Portfolio URL on job applications.

The sample projects are explicitly labelled as demonstrations and should not be represented as paid client work unless they actually are.
